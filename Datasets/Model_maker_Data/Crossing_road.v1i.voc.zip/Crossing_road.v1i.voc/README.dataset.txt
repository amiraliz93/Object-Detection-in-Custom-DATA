# Crossing_road > 2022-08-05 11:52pm
https://universe.roboflow.com/object-detection/crossing_road

Provided by Roboflow
License: Public Domain

